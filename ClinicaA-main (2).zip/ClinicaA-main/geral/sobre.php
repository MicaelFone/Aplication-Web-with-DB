<!-------------------------------------------------------------------------------
    Desenvolvimento Web
    PUCPR
    Profa. Cristina V. P. B. Souza
    Agosto/2022
---------------------------------------------------------------------------------->
<!-- Sobre -->


<footer class="w3-panel w3-padding w3-card-4 w3-light-grey w3-center w3-opacity">
    <p>
        <nav>
            <a class="w3-btn w3-theme w3-hover-white"
               onclick="document.getElementById('Sobre').style.display='block'">Sobre</a>
        </nav>
    </p>
</footer>