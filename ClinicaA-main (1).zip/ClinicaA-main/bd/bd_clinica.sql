-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Tempo de geração: 10-Set-2022 às 02:03
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

CREATE TABLE Producao( 
  Id_producao INT IDENTITY PRIMARY KEY NOT NULL, 
  Nome_da_producao VARCHAR(30) NOT NULL, 
  Descricao_sobre_a_producao VARCHAR(400) NOT NULL, 
  Id_tipo  INT NOT NULL,   
); 

INSERT INTO Producao(Nome_da_producao,Descricao_sobre_a_producao,Id_tipo) VALUES 
('Minions 2','Um filme de desenho animado com uma duração de 1hr31min para todos públicos',1), 
('Minions','Um filme de desenho animado para mais um público infantil com uma duração de 1hr31min,com uma classificão livre ao público.',2), 
('Transformers','Um filme de ação e aventura para um público partir de 10 anos com uma duração de 2h24min.',3), 
('Game of Thrones','Uma série de ação ,drama e aventura, em que possui 8 temporadas para um público a partir de 18 anos.',4), 
('Riverdale','Uma série de ação ,drama e aventura, que possui 6 temporadas para um público a partir de 14 anos.',5), 
('Friends','Uma série de comédia, que possui 12 temporadas para um público a partir de 10 anos.',6), 
('The last dance','Um documentário de 8 episódios em que conta a história da última temporada do time de basquete Chicago Bulls na temporada 1997-1998 ',7), 
('Winter on Fire','Um documentário em que retrata a luta da população ucraniana para acabar com a influencia russa no país entre o fim de 2013 e o começo de 2014.',8), 
('Enola Holmes' ,'Um filme de ação e aventura para um público acima de 10 anos',9), 
('Sherlock Holmes','Um filme de ação e aventura para mais um público a partir de 12 anos.',10);
INSERT INTO Producao(Nome_da_producao,Descricao_sobre_a_producao,Id_tipo) VALUES 
('Minions 3','Um filme de desenho animado com uma duração de 1hr31min para todos públicos',11), 
('Sonic','Um filme inspirado  para mais um público infantil com uma duração de 1hr30min,com uma classificão livre ao público.',12), 
('Titanic','Um filme de drama em baseado em fatos reias com uma duração de 2h24min.',13), 
('A barraca do beijo','Um filme de comédia com duraçmporadas para um público a partir de 18 anos.',14), 
('Missão Impossível','Uma filme ação,drama e aventura, que possui um tempo de 2hr apartir de 12 anos.',15)
GO
 
CREATE TABLE Producaotipo(                                                                                             
Id_tipo INT IDENTITY PRIMARY KEY NOT NULL, 
Nome_tipo VARCHAR(30) NOT NULL, 
); 
GO 
ALTER TABLE Producaotipo ADD CONSTRAINT UN_id_tipo UNIQUE (id_tipo); 

ALTER TABLE Producao ADD CONSTRAINT fk_id_producao_tipo FOREIGN KEY (Id_tipo) REFERENCES Producaotipo (Id_tipo) 
GO
INSERT INTO ProducaoTipo(Nome_tipo) VALUES 
('Filme'),
('Filme'),
('Filme'), 
('Filme'), 
('Série'), 
('Série'), 
('Série'), 
('Documentário'), 
('Documentário'), 
('Filme'), 
('Filme'),
('Filme'), 
('Filme'),
('Filme'), 
('Filme'); 




